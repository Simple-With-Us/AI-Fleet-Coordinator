---
name: board-ops
description: Use Linear through the simple-tools MCP tools as the first place to look and write.  File, claim, comment, and resolve fleet items (issue ids like BF-123).  Trigger whenever starting work, hunting open P0/P1s, reviewing a peer fix, closing a lane, or when the owner mentions the board, Linear, findings, or an issue id.
---

# Board CLI on Linear (MONET)

Linear is the system of record for fleet work (owner 2026-10-10), and the simple-tools MCP `linear_*` tools are how agents use it.  Workspace Simple With Us, `https://linear.app/simple-with-us`, one public team per app: ST, CT, UM, CTS, DD, AFC, PS, AR, CL, BF, HH, OPS, C, FL, CC, SWU.  Every issue has an identifier such as `BF-123`.  The old board's rows, the GitHub issues and the effort-log items were all imported, so the history is there too.

Humans use Linear in the browser.  Agents use the simple-tools MCP server:  `linear_list`, `linear_get_issue`, `linear_claim`, `linear_status`, `linear_comment`, `linear_file` and `linear_whoami` read and write Linear and sign each write with your seat.  The old board archive was retired on 2026-10-19, and the old board host now redirects to Linear (https://linear.app/simple-with-us).  The effort logs are archived.  Nothing mirrors to them any more.

## Invoke the tools

```text
linear_list --status open,in_progress --severity P0,P1
linear_list --team congress-trade
linear_get_issue <id>
```

`<id>` is a Linear identifier (`BF-123`), a full old board id, or the first 8 or more hex characters of an old board id.  Every output line ends with the identifier, so use it from then on.

The MCP server reads the Fleet app's credentials itself.  The secret must never appear on a command line, in `ps`, or in a transcript.  Do not use the claude.ai Linear connector or Composio to write to Linear: they act as Jay, not as a seat.

Claude Code only offers "Always Allow" when the command has a stable prefix.  An MCP tool call needs no allowlist entry at all.  If you fall back to the `simple-board` CLI, `simple-board stats` allowlists; `B=…/simple-board; $B stats`, `$(…)`, pipes, and `&&` chains do not.

**Your seat is proven by your own bearer, never chosen.**  The MCP `linear_*` tools read the seat bearer at the `SIMPLE_BOARD_BEARER_LOCATOR` your launcher bound to this run (a `FOLDER:KEY_NAME` location, never a value) and the fleet verifier names the seat.  There is no seat picker: `AGENT_SEAT`, `AGENT_LAUNCH_SEAT` and any other variable are ignored.  With no readable bearer the four writes (`linear_file`, `linear_claim`, `linear_status`, `linear_comment`) are refused, and the reads (`linear_list`, `linear_get_issue`) run without an identity.  A write needs the bearer-verified seat and nothing else:  pass `identity` = that seat.  The MCP tool `linear_whoami` prints the verified seat (`bearer-verified`) and whether writes are on.  The CLI fallback keeps its own rules:  `simple-board` is invoked literally, the `board` name on PATH is retired with its wrapper, `--env` is only `Mac` or `cloud`, and `--by` for this seat is `MONET`.

**Pass your session id.**  Every `linear_*` write (`linear_file`, `linear_claim`, `linear_comment`, `linear_status`), every `notes_create` / `notes_update` call (and `simple-notes`), and `apple-notes-coding.sh` needs your session id, so a headless resume-wake can find your session for the topic, and they refuse without one.  Pass it as `--session <id>` (the `session` argument on the MCP tools), else export `AGENT_SESSION`, else the tool reads your platform's own session variable, which your global rules file names.  Where a platform sets none that is known to be set (FX, Clutch, Antigravity, Muse Code, Grok Web), pass `--session <id>` or export `AGENT_SESSION`, using the id your app shows for the current chat.  An MCP server may not inherit the platform variable, so pass `session` explicitly on `notes_create` / `notes_update`; cloud seats have no shell env and always pass `session`.  Exempt, because they have one thread with the owner: every Grok bot, MA, JET, WISE and ECHO.  Notes get a small `Session: <id>` line under the timestamp.  A chat tag such as `session8` is not a session id and is refused.

## File / claim / talk / finish

```text
linear_file    title="Scout drops Senate rows on 502"  app=congress-trade  severity=P1  env=Mac
               description="path:line + repro"  session=<id>

linear_claim   id=<id>  comment="claimed: <lane path> @ <branch>"  session=<id>

linear_comment id=<id>  body="Verified on main; the shared helper is right."  session=<id>

linear_status  id=<id>  status=completed  session=<id>
linear_comment id=<id>  body="Landed in #2894."
```

The CLI fallback is the same four moves with the same flags:

```bash
simple-board file --title "Scout drops Senate rows on 502" --app congress-trade \
  --severity P1 --by MONET --env Mac --where "~/apps/lanes/Congress.Trade/<seat>-fix @ <branch>" \
  --desc "path:line + repro"

simple-board claim <id> --by MONET --env Mac --where "~/apps/lanes/Congress.Trade/<seat>-fix @ <branch>"

simple-board comment <id> --by MONET --text "Verified on main; the shared helper is right."

simple-board status <id> completed --resolution "Landed in #2894."
```

`app` takes an app team key (`CT`) or the old slug (`congress-trade`, `socratic-trade`, `usage-monitor`, `congress-trading-shared`, `dealdex`, `personal-site`, `fleet-infra`, which files to OPS).  If unsure, `linear_list_teams` prints the live team list.

Status values: `open`, `in_progress`, `addressed` (In Review), `completed` (Done), `deployed`, `wontfix`, `duplicate`, plus `parked`.  Two rules differ from the old board:

- `linear_status` with `status` = `duplicate` needs `of` = the canonical id, because Linear only makes a Duplicate through a link to the issue it duplicates.
- `linear_claim` is check-then-set.  The hosted server refuses an issue another seat holds In Progress; the `simple-board` CLI fallback still takes `--steal --reason "..."`.  A claim is the `claimed:<SEAT>` label plus a `CLAIMED` comment; `linear_status` with `status` = `open` releases it.  There is no 20-minute lease and no server lock, so a second claim in the same second can still collide.

The full verb table, id forms and exit codes are in `scripts/linear-board/README.md` in AI-Fleet-Coordinator.

## What you owe Linear

1. **Before substantial work:** list the app.  Claim the existing issue or file then claim.  Name the branch `<seat>/<id>-<slug>` (`monet/afc-123-zulip-cutover`).
2. **While working:** keep `--by MONET`, `--env Mac`, and `--where "lane path @ branch"` accurate.
3. **In the PR:** put `Fixes <ID>` in the body when the PR finishes the issue, and `Refs <ID>` for partial work.  A `Refs` PR never closes it, even with the id in the branch name.  Once Linear's GitHub automation is on (Jay enables it right after the cutover), a merge moves a `Fixes` issue to Done by itself; `linear_status` with `status` = `completed` does the same by hand, works before then, and is always safe to run.
4. **When done:** `completed`, or `deployed` only after the production check, with a resolution that names the PR and what changed.  Do not leave `in_progress` after you stopped.
5. **On a peer's item:** comment with evidence.  Reviewing fixes here is expected.

## Item kinds

`agent-report`, `review-finding`, `effort-row`, `github-issue` and `sentry` are labels now (`Kind`), not separate systems.  Nothing is mirrored in either direction: there is no writeback, no retired `mac-collab-sync`, and no effort log to land.  Imported effort-log items are ordinary issues, marked `imported`.

## Do not

- Write to Linear any way except the `linear_*` MCP tools (or the `simple-board` CLI fallback):  no connector, no personal API key, no raw GraphQL with a borrowed token.
- Use Linear as the only closeout.  The work topic in Zulip still gets its `DONE` post.
- File a duplicate because you did not `linear_list` first.
- Edit an archived `*-EFFORT-LOG.md` or `docs/EFFORT-LOG.md`.  They carry an Archived header and nobody reads them.

## Canon

- `~/apps/FLEET-PROTOCOL.md` § Linear and the Claim Lifecycle
- `scripts/linear-board/README.md` and `docs/protocols/linear-migration.md` in AI-Fleet-Coordinator
- The MCP guide:  `guide` with `section` = "Tools by Family"
- The CLI fallback help:  `simple-board --help` / `simple-board file --help`

Clutch's app acronym is `C` (owner 2026-10-23, AFC-333), the same as its live Linear team key.  `C-n` is a Clutch Linear issue and `C#n` a Clutch PR.  `CLUTCH`, legacy `CK`, `clutch`, `harness`, and `dsh-runtime` all route to that same team, and prior `CK-n` and `CLUTCH-n` identifiers remain resolvable.  `CC` is CodeCaps, never Clutch.
